:github_url: https://github.com/UniversalRobots/Universal_Robots_ROS2_Driver/blob/main/ur_robot_driver/doc/installation/toc.rst

############
Installation
############

This chapter explains how to install the ``ur_robot_driver``


.. toctree::
   :maxdepth: 4
   :caption: Contents:

   installation
   robot_setup
